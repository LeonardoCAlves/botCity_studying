#!/bin/bash

zip -r "bot_smartphone_casasBahia.zip" * -x "bot_smartphone_casasBahia.zip"